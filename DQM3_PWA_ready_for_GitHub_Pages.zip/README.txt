iPhoneで使う手順
1. ZIPを展開
2. GitHub PagesなどHTTPSで公開
3. iPhoneのSafariで公開URLを1回開く
4. 共有 → ホーム画面に追加
5. 以後はホーム画面から起動。初回読み込み後はオフライン利用可能

※ChatGPT内プレビューや file:// 直開きではPWAとして動きません。
※現在は動作確認用9体データです。